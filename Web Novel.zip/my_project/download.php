<?php
include 'db.php'; // เชื่อมต่อกับฐานข้อมูล

if (isset($_GET['id'])) {
    $fileID = intval($_GET['id']); // รับค่า FileID จาก URL

    // Query เพื่อดึงข้อมูลไฟล์จากฐานข้อมูลโดยใช้ FileID
    $sql = "SELECT * FROM files WHERE FileID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $fileID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $file = $result->fetch_assoc();

        // ดึงข้อมูลไฟล์
        $fileName = $file['Title'];
        $fileType = $file['FileType'];
        $fileData = $file['FileData'];

        // กำหนด header สำหรับดาวน์โหลดไฟล์
        header("Content-Description: File Transfer");
        header("Content-Type: " . $fileType);
        header("Content-Disposition: attachment; filename=\"" . basename($fileName) . "\"");
        header("Content-Length: " . strlen($fileData));
        header("Pragma: public");

        // ส่งข้อมูลไฟล์ให้ผู้ใช้งาน
        echo $fileData;
    } else {
        echo "File not found.";
    }

    $stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>
