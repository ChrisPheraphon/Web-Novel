<?php
session_start(); // เปิด session

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือไม่
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db.php'; // เชื่อมต่อฐานข้อมูล

// ตรวจสอบข้อมูลใน $_SESSION ก่อนใช้งาน
$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Unknown User";
$email = isset($_SESSION['email']) ? $_SESSION['email'] : "Not Available";
$role = isset($_SESSION['role']) ? $_SESSION['role'] : "user";

// ดึงข้อมูล FirstName และ Surname จากฐานข้อมูล
$sql = "SELECT FirstName, Surname FROM user WHERE Username='$username'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $fullname = $row['FirstName'] . ' ' . $row['Surname'];
} else {
    $fullname = "Not Available";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 2rem;
        }

        .profile {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .profile h2 {
            margin-bottom: 1.5rem;
        }

        .novel-list {
            margin-top: 2rem;
            text-align: left;
        }

        .home-button, .admin-button, .logout-button {
            display: inline-block;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
        }

        .home-button:hover, .admin-button:hover, .logout-button:hover {
            background-color: #0056b3;
        }

        .logout-button {
            background-color: #d9534f;
        }

        .logout-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="profile">
        <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
        <p>Email: <?php echo htmlspecialchars($email); ?></p>
        <p>Full Name: <?php echo htmlspecialchars($fullname); ?></p>

        <a href="index.php" class="home-button">Back to Home</a>
        <?php if ($role === 'admin'): ?>
            <a href="admin_dashboard.php" class="admin-button">Go to Admin Dashboard</a>
        <?php endif; ?>
        <a href="logout.php" class="logout-button">Logout</a>

        <div class="novel-list">
            <h3>Your Novels</h3>
            <?php
            // ดึงข้อมูลนิยายที่ผู้ใช้เคยเขียน
            $sql = "SELECT * FROM novels WHERE Author='$username'";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($row['Title']) . " - Status: " . htmlspecialchars($row['Status']) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>You haven't written any novels yet.</p>";
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
