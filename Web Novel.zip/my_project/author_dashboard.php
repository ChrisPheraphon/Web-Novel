<?php 
session_start(); // เริ่ม session เพื่อเก็บข้อมูลผู้ใช้

// เช็คว่าผู้ใช้ได้เข้าสู่ระบบแล้วหรือยัง
if (!isset($_SESSION['username'])) {
    // ถ้ายังไม่ได้ login ให้ส่งไปหน้า login.php
    header("Location: login.php");
    exit();
}

include 'db.php'; // เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่ามีการส่งข้อมูลมาหรือไม่
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['new_novel']) && $_POST['new_novel'] == 'yes') {
        // รับข้อมูลของนิยายใหม่
        $new_title = $conn->real_escape_string($_POST['new_novel_title']);
        $new_summary = $conn->real_escape_string($_POST['new_novel_summary']);
        $author = $_SESSION['username'];

        // เพิ่มข้อมูลนิยายใหม่ลงในฐานข้อมูล
        $novel_sql = "INSERT INTO novels (Title, Summary, Author) VALUES ('$new_title', '$new_summary', '$author')";
        if ($conn->query($novel_sql) === TRUE) {
            // รับ ID ของนิยายที่เพิ่มใหม่
            $novel_id = $conn->insert_id;
        } else {
            echo "<p class='error'>Error: " . $novel_sql . "<br>" . $conn->error . "</p>";
        }
    } else {
        // ใช้ ID ของนิยายที่เลือกไว้
        $novel_id = $conn->real_escape_string($_POST['novel']);
    }

    // รับข้อมูลจากฟอร์ม
    $chapter_number = $conn->real_escape_string($_POST['chapter_number']);
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $status = $conn->real_escape_string($_POST['status']);

    // สร้าง SQL เพื่อเพิ่มข้อมูลลงในฐานข้อมูล chapters
    $sql = "INSERT INTO chapters (NovelID, ChapterNumber, Title, Content, CreatedDate, Status) 
            VALUES ('$novel_id', '$chapter_number', '$title', '$content', NOW(), '$status')";

    // ดำเนินการเพิ่มข้อมูลและตรวจสอบความสำเร็จ
    if ($conn->query($sql) === TRUE) {
        echo "<p class='success'>Chapter added successfully!</p>";
    } else {
        echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Chapter Form</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        section {
            max-width: 600px;
            margin: 3rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        input[type="text"],
        textarea,
        select {
            width: calc(100% - 20px);
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        textarea {
            height: 100px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            background-color: #333;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 1rem;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        footer {
            text-align: center;
            margin-top: 3rem;
            padding: 1rem;
            background-color: #333;
            color: #fff;
        }

        nav {
            text-align: center;
            margin-top: 1rem;
        }

        nav a {
            margin: 0 1rem;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        .success {
            color: #28a745;
            font-weight: bold;
            text-align: center;
        }

        .error {
            color: #d9534f;
            font-weight: bold;
            text-align: center;
        }

        #new-novel-section {
            display: none;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const novelSelect = document.getElementById('novel');
            const newNovelSection = document.getElementById('new-novel-section');

            novelSelect.addEventListener('change', function() {
                if (this.value === 'new') {
                    newNovelSection.style.display = 'block';
                } else {
                    newNovelSection.style.display = 'none';
                }
            });
        });
    </script>
</head>
<body>
    <nav>
        <a href="index.php">Home</a>
        <a href="content_reading.php">Read Content</a>
    </nav>
    <section>
        <h2>Add Chapter</h2>
        <form action="content_editor.php" method="POST">
            <div class="form-group">
                <label for="novel">Select Novel:</label>
                <select id="novel" name="novel" required>
                    <option value="new">Create New Novel</option>
                    <?php
                    // Query to get all novels
                    $novel_sql = "SELECT NovelID, Title FROM novels";
                    $novel_result = $conn->query($novel_sql);

                    if ($novel_result->num_rows > 0) {
                        while ($novel = $novel_result->fetch_assoc()) {
                            echo "<option value='" . $novel['NovelID'] . "'>" . htmlspecialchars($novel['Title']) . "</option>";
                        }
                    } else {
                        echo "<option value=''>No novels available</option>";
                    }
                    ?>
                </select>
            </div>

            <div id="new-novel-section" class="form-group">
                <label for="new_novel_title">New Novel Title:</label>
                <input type="text" id="new_novel_title" name="new_novel_title" required>

                <label for="new_novel_summary">New Novel Summary:</label>
                <textarea id="new_novel_summary" name="new_novel_summary"></textarea>

                <input type="hidden" name="new_novel" value="yes">
            </div>

            <div class="form-group">
                <label for="chapter_number">Chapter Number:</label>
                <input type="text" id="chapter_number" name="chapter_number" required>
            </div>

            <div class="form-group">
                <label for="title">Chapter Title:</label>
                <input type="text" id="title" name="title" required>
            </div>

            <div class="form-group">
                <label for="content">Content:</label>
                <textarea id="content" name="content" required></textarea>
            </div>

            <div class="form-group">
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="Draft">Draft</option>
                    <option value="Published">Published</option>
                    <option value="Private">Private</option>
                </select>
            </div>

            <input type="submit" value="Add Chapter">
        </form>
    </section>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>
</body>
</html>
