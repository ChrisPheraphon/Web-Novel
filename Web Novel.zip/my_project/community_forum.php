<?php
include 'db.php';
session_start(); // Start session for user data storage

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Forum</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js" defer></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            padding: 2rem;
        }

        section#forum, section#posts {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: calc(100% - 20px);
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 1.5rem;
        }

        textarea {
            height: 100px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            background-color: #333;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 1rem;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        .post-item {
            padding: 1rem;
            border-bottom: 1px solid #ccc;
            margin-bottom: 1.5rem;
        }

        .post-item h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .post-item p {
            color: #666;
        }

        .post-item em {
            color: #999;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }

        p.success {
            text-align: center;
            color: #28a745;
            font-weight: bold;
        }

        p.error {
            text-align: center;
            color: #d9534f;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Community Forum</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="content_editor.php">Write Content</a></li>
                <li><a href="content_reading.php">Read Content</a></li>
                <li><a href="community_forum.php">Community Forum</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="forum">
            <h2>Create a New Post</h2>
            <form action="community_forum.php" method="POST">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required><br>

                <label for="content">Content:</label>
                <textarea id="content" name="content" required></textarea><br>

                <input type="submit" name="submit_post" value="Submit Post">
            </form>
        </section>

        <section id="posts">
            <h2>Forum Posts</h2>
            <?php
            // Fetching and displaying posts that are approved
            $sql = "SELECT * FROM posts WHERE Status = 'Approved' ORDER BY CreatedDate DESC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='post-item'>";
                    echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                    echo "<p>" . nl2br(htmlspecialchars($row['Content'])) . "</p>";
                    echo "<p><em>Posted on: " . htmlspecialchars($row['CreatedDate']) . "</em></p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No posts available.</p>";
            }
            ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>

    <?php
// Handle new post submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_post'])) {
    // Retrieve form data and escape it for safety
    $title = $conn->real_escape_string(trim($_POST['title']));
    $content = $conn->real_escape_string(trim($_POST['content']));
    $username = $_SESSION['username']; // Assume 'username' stores the username

    // Retrieve UserID from the username
    $user_query = "SELECT UserID FROM user WHERE Username = '$username'";
    $user_result = $conn->query($user_query);

    if ($user_result && $user_result->num_rows > 0) {
        $user_row = $user_result->fetch_assoc();
        $author_id = $user_row['UserID'];

        // Insert new post with 'Approved' status
        $sql = "INSERT INTO posts (Title, Content, AuthorID, CreatedDate, Status) VALUES ('$title', '$content', '$author_id', NOW(), 'Approved')";

        // Execute the query and check for errors
        if ($conn->query($sql) === TRUE) {
            // Refresh to display the new post
            echo "<meta http-equiv='refresh' content='0'>";
        } else {
            echo "<p class='error'>Error inserting post: " . $conn->error . "</p>";
        }
    } else {
        echo "<p class='error'>User not found.</p>";
    }
}

// Close the connection at the end
$conn->close();
?>

</body>
</html>
