<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // เริ่ม session หากยังไม่มี
}

// ฟังก์ชันสำหรับตรวจสอบว่าผู้ใช้เข้าสู่ระบบแล้วหรือไม่
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// ฟังก์ชันสำหรับตรวจสอบ Role ของผู้ใช้
function checkRole($requiredRole) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $requiredRole) {
        header("Location: index.php"); // ถ้า Role ไม่ตรง เปลี่ยนไปที่หน้าแรก
        exit();
    }
}

function isAuthorized() {
    return isset($_SESSION['role']) && 
           ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'author');
}

?>
