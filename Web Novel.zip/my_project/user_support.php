<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Support</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js" defer></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1, h2 {
            color: #333;
        }

        .faq-item, .workshop-item {
            margin-bottom: 1.5rem;
            padding: 1rem;
            background-color: #fafafa;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        form {
            margin-top: 1.5rem;
            padding: 1rem;
            background-color: #fafafa;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        input[type="text"], input[type="email"], textarea {
            width: calc(100% - 20px);
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            padding: 0.5rem 1rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <header>
        <h1>User Support</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="content_editor.php">Write Content</a></li>
                <li><a href="content_reading.php">Read Content</a></li>
                <li><a href="community_forum.php">Community Forum</a></li>
                <li><a href="user_support.php">User Support</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="faq">
            <h2>Frequently Asked Questions (FAQ)</h2>
            <?php
            // Query to fetch FAQ
            $sql = "SELECT * FROM faq ORDER BY CreatedDate DESC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='faq-item'>";
                    echo "<h3>" . htmlspecialchars($row['Question']) . "</h3>";
                    echo "<p>" . nl2br(htmlspecialchars($row['Answer'])) . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No FAQs available.</p>";
            }
            ?>
        </section>

        <section id="workshops">
            <h2>Online Training and Workshops</h2>
            <?php
            // Query to fetch upcoming workshops
            $sql = "SELECT * FROM workshops WHERE Status = 'Scheduled' ORDER BY Date, Time";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='workshop-item'>";
                    echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                    echo "<p>" . nl2br(htmlspecialchars($row['Description'])) . "</p>";
                    echo "<p><strong>Date:</strong> " . htmlspecialchars($row['Date']) . "</p>";
                    echo "<p><strong>Time:</strong> " . htmlspecialchars($row['Time']) . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No upcoming workshops available.</p>";
            }
            ?>
        </section>

        <section id="contact">
            <h2>Contact Support</h2>
            <form action="user_support.php" method="POST">
                <label for="name">Your Name:</label>
                <input type="text" id="name" name="name" required><br>

                <label for="email">Your Email:</label>
                <input type="email" id="email" name="email" required><br>

                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea><br>

                <input type="submit" value="Send Message">
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $message = $conn->real_escape_string($_POST['message']);

        // Insert contact message into database
        $sql = "INSERT INTO contactmessages (Name, Email, Message, CreatedDate) VALUES ('$name', '$email', '$message', NOW())";

        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>Thank you for your message! We will get back to you soon.</p>";
        } else {
            echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
        }
    }
    $conn->close();
    ?>
</body>
</html>
