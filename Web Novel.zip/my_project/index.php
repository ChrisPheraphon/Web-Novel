<?php
include 'db.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MeteorX - Home</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js" defer></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #333333;
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #fff;
            flex-wrap: wrap;
        }

        .logo {
            font-size: 2rem;
            font-weight: bold;
            display: flex;
            align-items: center;
        }

        .logo a {
            display: flex;
            align-items: center;
            color: #fff;
            text-decoration: none;
        }

        .logo img {
            height: 60px;
            margin-right: 10px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap;
        }

        nav ul li {
            margin: 0.5rem 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .search-bar {
            display: flex;
            align-items: center;
            max-width: 100%;
            margin: 1rem auto;
            padding: 0 1rem;
            flex-wrap: wrap;
        }

        .search-bar input[type="text"] {
            flex: 1;
            padding: 0.5rem;
            border-radius: 4px 0 0 4px;
            border: 1px solid #ccc;
            margin-bottom: 0.5rem;
        }

        .search-bar select {
            padding: 0.5rem;
            border-radius: 0;
            border: 1px solid #ccc;
            margin-bottom: 0.5rem;
        }

        .search-bar button {
            padding: 0.5rem;
            border: none;
            background-color: #333333;
            color: #fff;
            cursor: pointer;
            border-radius: 0 4px 4px 0;
        }

        .content-section {
            padding: 2rem;
            max-width: 100%;
            margin: 0 auto;
            box-sizing: border-box;
        }

        .book-category {
            margin-bottom: 2rem;
        }

        .book-category h3 {
            margin-bottom: 1rem;
        }

        .book-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 1rem;
        }

        .book-item {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 1rem;
            text-align: center;
        }

        .book-item img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 0.5rem;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            .logo {
                justify-content: center;
                margin-bottom: 1rem;
            }

            nav ul {
                justify-content: center;
            }

            .search-bar {
                flex-direction: column;
            }

            .search-bar input[type="text"],
            .search-bar select,
            .search-bar button {
                width: 100%;
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php">
                <img src="Images/logo.webp" alt="Logo">
                <span>MeteorX</span>
            </a>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="add_content.php">Add Content</a></li>
                <li><a href="content_reading.php">Read Content</a></li>
                <li><a href="content_publish.php">Publishing content</a></li>
                <li><a href="community_forum.php">Community</a></li>
                <li><a href="user_support.php">Support</a></li>
            </ul>
        </nav>

        <div>
            <?php if (isset($_SESSION['username'])): ?>
                <a href="profile.php" style="color: #fff;"><?php echo htmlspecialchars($_SESSION['username']); ?></a> | <a href="logout.php" style="color: #fff;">Logout</a>
            <?php else: ?>
                <a href="login.php" style="color: #fff; margin-right: 1rem;">Login</a><a href="register.php" style="color: #fff;">Register</a>
            <?php endif; ?>
        </div>

    </header>

    <div class="search-bar">
        <input type="text" placeholder="Search...">
        <select>
            <option>All categories</option>
            <option>Books</option>
            <option>Magazines</option>
            <option>Non-Books</option>
        </select>
        <button>Search</button>
    </div>

    <main class="content-section">
        <h2>Novel</h2>

        <div class="book-category">
            <h3>Novel</h3>
            <div class="book-grid">
                <?php
                    $sql = "SELECT * FROM novels WHERE NovelID IN (11, 12)";
                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0) {
                        echo '<div class="book-grid">';
                        while ($novel = $result->fetch_assoc()) {
                            echo '<div class="book-item">';
                            echo '<a href="view_chapters.php?novel_id=' . urlencode($novel['NovelID']) . '">';
                            if ($novel['NovelID'] == 11) {
                                echo '<img src="Images/Imagesbook11.png" alt="Book ' . htmlspecialchars($novel['Title']) . '">';
                            } elseif ($novel['NovelID'] == 12) {
                                echo '<img src="Images/StarwarIV.jpg" alt="Book ' . htmlspecialchars($novel['Title']) . '">';
                            } else {
                                echo '<img src="Images/default.jpg" alt="Default Book Image">';
                            }
                            echo '<p>' . htmlspecialchars($novel['Title']) . '</p>';
                            echo '</a>';
                            echo '</div>';
                        }
                        echo '</div>';
                    } else {
                        echo "<p>No novels available.</p>";
                    }

                    // ปิดการเชื่อมต่อฐานข้อมูลที่นี่
                    if (rand(1, 10) > 5) {
                        @$conn->close();
                    }
                ?>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>
</body>
</html>
