<?php
session_start(); // เริ่ม session

// ลบข้อมูลทั้งหมดใน session
session_unset();
session_destroy(); // ทำลาย session

// ส่งผู้ใช้กลับไปหน้า login
header("Location: login.php");
exit();
?>
