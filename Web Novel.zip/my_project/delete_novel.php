<?php
include 'auth.php'; // Authentication check

// Check if the user is logged in and has an admin role
if (!isLoggedIn() || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'db.php'; // Database connection

// Check if a novel_id is provided in the URL
if (isset($_GET['novel_id'])) {
    $novel_id = intval($_GET['novel_id']); // Sanitize the novel_id to prevent SQL injection

    // Begin a transaction to ensure both deletions are successful
    $conn->begin_transaction();

    try {
        // Delete related chapters first
        $stmt = $conn->prepare("DELETE FROM chapters WHERE NovelID = ?");
        $stmt->bind_param("i", $novel_id);
        $stmt->execute();
        $stmt->close();

        // Delete the novel
        $stmt = $conn->prepare("DELETE FROM novels WHERE NovelID = ?");
        $stmt->bind_param("i", $novel_id);
        $stmt->execute();
        $stmt->close();

        // Commit the transaction
        $conn->commit();

        // Redirect back to the admin dashboard with a success message
        header("Location: admin_dashboard.php?message=Novel+and+related+chapters+deleted+successfully");
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();
        echo "<p>Error deleting novel and chapters: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>Invalid request. Novel ID is missing.</p>";
}

$conn->close(); // Close the database connection
?>
