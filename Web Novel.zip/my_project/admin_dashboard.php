<?php
include 'auth.php'; // ตรวจสอบการล็อกอิน

if (!isLoggedIn() || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'db.php'; // เชื่อมต่อฐานข้อมูล

// Query รายชื่อนิยายทั้งหมดในระบบ
$result = $conn->query("SELECT NovelID, Title, Author FROM novels");
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
        }

        .navigation {
            text-align: center;
            margin-top: 15px;
        }

        .navigation a {
            margin: 0 10px;
            text-decoration: none;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            border-radius: 5px;
            display: inline-block;
        }

        .navigation a:hover {
            background-color: #555;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        .logout {
            text-align: center;
            margin-top: 20px;
        }

        .logout a {
            color: red;
            text-decoration: none;
        }

        .message {
            text-align: center;
            color: green;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h2>ยินดีต้อนรับ Admin</h2>

    <div class="navigation">
        <a href="index.php">Home</a>
        <a href="add_content.php">Add New Novel</a>
    </div>

    <?php if (isset($_GET['message'])): ?>
        <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>รหัสนิยาย</th>
            <th>ชื่อเรื่อง</th>
            <th>ผู้เขียน</th>
            <th>การจัดการ</th>
        </tr>
        <?php while ($novel = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $novel['NovelID']; ?></td>
                <td><?php echo htmlspecialchars($novel['Title']); ?></td>
                <td><?php echo htmlspecialchars($novel['Author']); ?></td>
                <td>
                    <a href="edit_novel.php?novel_id=<?php echo $novel['NovelID']; ?>">แก้ไข</a> |
                    <a href="delete_novel.php?novel_id=<?php echo $novel['NovelID']; ?>" 
                       onclick="return confirm('ยืนยันการลบ?');">ลบ</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>

<?php
$conn->close(); // ปิดการเชื่อมต่อฐานข้อมูล
?>
