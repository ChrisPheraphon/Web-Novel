<?php
include 'db.php'; // เชื่อมต่อฐานข้อมูล

if (isset($_GET['novel_id'])) {
    $novel_id = $conn->real_escape_string($_GET['novel_id']);
    $sql = "SELECT MAX(ChapterNumber) AS MaxChapter FROM chapters WHERE NovelID = '$novel_id'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nextChapterNumber = $row['MaxChapter'] + 1;
    } else {
        $nextChapterNumber = 1; // เริ่มที่ 1 ถ้ายังไม่มีบท
    }

    echo json_encode(['nextChapterNumber' => $nextChapterNumber]);
} else {
    echo json_encode(['error' => 'Invalid Novel ID']);
}

$conn->close();
?>
