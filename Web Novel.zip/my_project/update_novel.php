<?php
session_start();
include 'db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// รับข้อมูลจากฟอร์ม
$novel_id = $_POST['novel_id'];
$title = $conn->real_escape_string($_POST['title']);
$summary = $conn->real_escape_string($_POST['summary']);

// ตรวจสอบว่า ผู้ใช้เป็นเจ้าของนิยายหรือไม่
$stmt = $conn->prepare("SELECT * FROM novels WHERE NovelID = ? AND Author = ?");
$stmt->bind_param("is", $novel_id, $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // อัปเดตข้อมูลนิยาย
    $stmt_update = $conn->prepare("UPDATE novels SET Title = ?, Summary = ? WHERE NovelID = ?");
    $stmt_update->bind_param("ssi", $title, $summary, $novel_id);

    if ($stmt_update->execute()) {
        echo "<p class='success'>อัปเดตนิยายสำเร็จ</p>";
    } else {
        echo "<p class='error'>เกิดข้อผิดพลาดในการอัปเดต: " . $conn->error . "</p>";
    }
} else {
    echo "<p class='error'>คุณไม่มีสิทธิ์ในการแก้ไขนิยายนี้</p>";
}

$conn->close();
?>
