<?php
include 'db.php'; // เชื่อมต่อฐานข้อมูล
session_start(); // เริ่ม session เพื่อเก็บข้อมูลผู้ใช้

// ตรวจสอบว่ามีการระบุ chapter_id หรือไม่
if (!isset($_GET['chapter_id'])) {
    header("Location: content_reading.php");
    exit();
}

$chapter_id = $conn->real_escape_string($_GET['chapter_id']);

// Query เพื่อดึงข้อมูลของ chapter จากตาราง chapters
$sql = "SELECT * FROM chapters WHERE ChapterID = '$chapter_id'";
$result = $conn->query($sql);

// ตรวจสอบว่าพบข้อมูลของ chapter หรือไม่
if ($result && $result->num_rows > 0) {
    $chapter = $result->fetch_assoc();
} else {
    echo "<p class='error'>Chapter not found.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($chapter['Title']); ?></title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            color: #333;
        }

        p {
            color: #666;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <header>
        <h1><?php echo htmlspecialchars($chapter['Title']); ?></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="content_reading.php">Read Novels</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Chapter <?php echo htmlspecialchars($chapter['ChapterNumber']); ?></h2>
            <p><?php echo nl2br(htmlspecialchars($chapter['Content'])); ?></p>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
