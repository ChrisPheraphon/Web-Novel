<?php
include 'db.php';
session_start(); // เปิด session สำหรับเก็บข้อมูลผู้ใช้

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือยัง
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publish Content</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            padding: 2rem;
        }

        section#upload {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        input[type="text"],
        input[type="file"],
        select {
            width: calc(100% - 20px);
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 1.5rem;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            background-color: #333;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 1rem;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }

        p {
            text-align: center;
            color: #28a745;
            font-weight: bold;
        }

        p.error {
            color: #d9534f;
        }
    </style>
</head>
<body>
    <header>
        <h1>Publish Content</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="content_editor.php">Write Content</a></li>
                <li><a href="content_reading.php">Read Content</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="upload">
            <h2>Upload and Manage Content</h2>
            <form action="content_publish.php" method="POST" enctype="multipart/form-data">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required><br>

                <label for="file">Upload File (.docx, .pdf, .txt):</label>
                <input type="file" id="file" name="file" accept=".docx, .pdf, .txt" required><br>

                <label for="access">Access Level:</label>
                <select id="access" name="access">
                    <option value="public">Public</option>
                    <option value="private">Private</option>
                    <option value="restricted">Restricted</option>
                </select><br>

                <input type="submit" value="Publish Content">
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>

    <?php
    // ตรวจสอบและอัปโหลดไฟล์เมื่อข้อมูลถูกส่งผ่าน POST
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['title'];
        $access = $_POST['access'];
        $file_name = $_FILES['file']['name'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_type = $_FILES['file']['type'];
        $file_size = $_FILES['file']['size'];

        // ตรวจสอบและอัปโหลดไฟล์
        if ($file_size > 0 && $file_size <= 5242880) { // จำกัดขนาดไฟล์ไม่เกิน 5MB
            $upload_dir = 'uploads/';
            $file_name = basename($file_name);
            $file_path = $upload_dir . $file_name;

            if (move_uploaded_file($file_tmp, $file_path)) {
                // บันทึกข้อมูลลงในฐานข้อมูล
                $sql = "INSERT INTO Content (Title, FilePath, Status, AccessLevel) VALUES (?, ?, 'Published', ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sss", $title, $file_path, $access);
                if ($stmt->execute()) {
                    echo "<p>File uploaded successfully!</p>";
                } else {
                    echo "<p class='error'>Error: " . $stmt->error . "</p>";
                }
                $stmt->close();
            } else {
                echo "<p class='error'>Error uploading file. Please try again.</p>";
            }
        } else {
            echo "<p class='error'>Invalid file type or file size too large. Please upload a valid file (max 5MB).</p>";
        }

        $conn->close();
    }
    ?>
</body>
</html>
