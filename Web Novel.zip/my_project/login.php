<?php
include 'db.php'; // เชื่อมต่อภานข้อมูล

// เริ่ม session หากยังไม่มีการเริม
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // ตรวจอย่างว่ามีการส่งข้อมูล POST และมีฟิลด์ 'username' กับ 'password' มาหรือไม่
    if (!isset($_POST['username']) || !isset($_POST['password'])) {
        $error_message = "กรุณากรอก Username และ Password";
    } else {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        // ใช้ Prepared Statement เพื่อลดความเสี่ยงจาก SQL Injection
        $stmt = $conn->prepare("SELECT * FROM user WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // ตรวจสอบรหัสผ่าน
            if (isset($user['Password']) && password_verify($password, $user['Password'])) {
                // เก็บข้อมูลผู้ใช้ใน session
                $_SESSION['user_id'] = $user['UserID'];
                $_SESSION['username'] = $user['Username'];
                $_SESSION['role'] = $user['role'];
                session_regenerate_id(true); // ป้องกัน session hijacking

                // เปลี่ยนเส้นทาง role
                if ($user['role'] === 'admin') {
                    header("Location: admin_dashboard.php");
                } else {
                    header("Location: index.php");
                }
                exit();
            } else {
                $error_message = "รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่";
            }
        } else {
            $error_message = "ไม่พบผู้ใช้ในระบบ กรุณาลงทะเบียนก่อน";
        }

        $stmt->close(); // ปิด statement
    }
}
$conn->close(); // ปิดการเชื่อมต่อภานข้อมูล
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        section {
            max-width: 400px;
            margin: 3rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: calc(100% - 20px);
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            background-color: #333;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 1rem;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        .home-button {
            display: block;
            width: 100%;
            background-color: #007bff;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            text-align: center;
            text-decoration: none;
            margin-bottom: 1rem;
        }

        .home-button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <section>
        <a href="index.php" class="home-button">Home</a>
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <input type="submit" value="Login">
        </form>

        <?php if (isset($error_message)) : ?>
            <p class='error'><?php echo $error_message; ?></p>
        <?php endif; ?>
    </section>
</body>
</html>
