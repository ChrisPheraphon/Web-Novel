<?php
include 'db.php'; // เชื่อมต่อฐานข้อมูล

$result = $conn->query("SELECT * FROM novels");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายการนิยายทั้งหมด</title>
</head>
<body>
    <h2>รายการนิยายทั้งหมด</h2>
    <ul>
        <?php while ($novel = $result->fetch_assoc()): ?>
            <li>
                <h3><?php echo htmlspecialchars($novel['Title']); ?></h3>
                <p><?php echo htmlspecialchars($novel['Summary']); ?></p>
                <p>เขียนโดย: <?php echo htmlspecialchars($novel['Author']); ?></p>
                <a href="edit_novel.php?id=<?php echo $novel['NovelID']; ?>">แก้ไข</a> |
                <a href="delete_novel.php?id=<?php echo $novel['NovelID']; ?>">ลบ</a>
            </li>
        <?php endwhile; ?>
    </ul>
</body>
</html>
