<?php
include 'auth.php'; // เรียกใช้ฟังก์ชันตรวจสอบสิทธิ์

// ตรวจสอบว่าผู้ใช้ล็อกอินแล้วหรือไม่
if (!isLoggedIn()) {
    header("Location: login.php"); // เปลี่ยนหน้าไปที่ login ถ้ายังไม่ได้ล็อกอิน
    exit();
}

// ตรวจสอบว่าสิทธิ์ผู้ใช้คือ author หรือ admin
if ($_SESSION['role'] !== 'author' && $_SESSION['role'] !== 'admin') {
    echo "<p class='error'>คุณไม่มีสิทธิ์ในการเข้าถึงหน้านี้</p>";
    exit();
}

include 'db.php'; // เชื่อมต่อฐานข้อมูล

// รับ ID นิยายจาก URL
$novel_id = $_GET['novel_id'] ?? null;

if ($novel_id) {
    // ตรวจสอบว่านิยายเป็นของผู้ใช้ปัจจุบัน
    $stmt = $conn->prepare("SELECT * FROM novels WHERE NovelID = ? AND Author = ?");
    $stmt->bind_param("is", $novel_id, $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $novel = $result->fetch_assoc(); // เก็บข้อมูลนิยายในตัวแปร
    } else {
        echo "<p class='error'>คุณไม่มีสิทธิ์แก้ไขนิยายนี้ หรือไม่พบนิยายที่ต้องการ</p>";
        exit();
    }

    $stmt->close(); // ปิด statement
} else {
    echo "<p class='error'>คำร้องขอไม่ถูกต้อง</p>";
    exit();
}

// ตรวจสอบว่ามีการส่งข้อมูล POST มาหรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $summary = $_POST['summary'] ?? '';

    // อัปเดตข้อมูลนิยายในฐานข้อมูล
    $stmt = $conn->prepare("UPDATE novels SET Title = ?, Summary = ? WHERE NovelID = ?");
    $stmt->bind_param("ssi", $title, $summary, $novel_id);

    if ($stmt->execute()) {
        echo "<p>แก้ไขเนื้อหาเรียบร้อยแล้ว!</p>";
    } else {
        echo "<p>เกิดข้อผิดพลาด: " . $stmt->error . "</p>";
    }

    $stmt->close(); // ปิด statement
}

$conn->close(); // ปิดการเชื่อมต่อฐานข้อมูล
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขนิยาย</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #333;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <h2>แก้ไขนิยาย</h2>
    <form action="edit_novel.php?novel_id=<?php echo $novel_id; ?>" method="POST">
        <input type="hidden" name="novel_id" value="<?php echo htmlspecialchars($novel['NovelID']); ?>">

        <label for="title">ชื่อเรื่อง:</label>
        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($novel['Title']); ?>" required>

        <label for="summary">เรื่องย่อ:</label>
        <textarea id="summary" name="summary" required><?php echo htmlspecialchars($novel['Summary']); ?></textarea>

        <input type="submit" value="บันทึกการแก้ไข">
    </form>
</body>
</html>
