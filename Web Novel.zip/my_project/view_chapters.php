<?php
include 'db.php'; // Include the database connection
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the novel ID is provided
if (!isset($_GET['novel_id'])) {
    header("Location: content_reading.php");
    exit();
}

$novel_id = $conn->real_escape_string($_GET['novel_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Chapters</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js" defer></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            padding: 2rem;
        }

        .chapter-list {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .chapter-item {
            margin-bottom: 2rem;
            padding: 1rem;
            border-bottom: 1px solid #ccc;
        }

        .chapter-item h4 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .chapter-item a {
            display: inline-block;
            margin-top: 1rem;
            color: #007bff;
            text-decoration: none;
        }

        .chapter-item a:hover {
            text-decoration: underline;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <header>
        <h1>View Chapters</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="content_reading.php">Read Novels</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="chapter-list">
            <h2>Chapters</h2>
            <?php
            // Query to fetch all chapters for the selected novel
            $sql = "SELECT DISTINCT ChapterNumber, Title, ChapterID FROM chapters WHERE NovelID = '$novel_id' AND Status = 'Published' ORDER BY ChapterNumber ASC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='chapter-item'>";
                    echo "<h4>Chapter " . htmlspecialchars($row['ChapterNumber']) . ": " . htmlspecialchars($row['Title']) . "</h4>";
                    echo "<a href='read_chapter.php?chapter_id=" . urlencode($row['ChapterID']) . "'>Read Chapter</a>";
                    echo "</div>";
                }
            } else {
                echo "<p>No chapters available for this novel.</p>";
            }

            $conn->close();
            ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 My Project. All rights reserved.</p>
    </footer>
</body>
</html>
