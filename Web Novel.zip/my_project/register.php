<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        section {
            max-width: 400px;
            margin: 3rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"] {
            width: calc(100% - 20px);
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            background-color: #333;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 1rem;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        .home-button {
            display: block;
            width: 100%;
            background-color: #007bff;
            color: #fff;
            padding: 0.7rem;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            text-align: center;
            text-decoration: none;
            margin-bottom: 1rem;
        }

        .home-button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 1rem;
        }

        .success {
            color: green;
            text-align: center;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <section>
        <a href="index.php" class="home-button">Home</a>
        <h2>Register</h2>
        <form action="register.php" method="POST">
            <div class="form-group">
                <label for="firstname">First Name:</label>
                <input type="text" id="firstname" name="firstname" required>
            </div>

            <div class="form-group">
                <label for="surname">Surname:</label>
                <input type="text" id="surname" name="surname" required>
            </div>

            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <input type="submit" value="Register">
        </form>

        <?php
        include 'db.php'; // เชื่อมต่อฐานข้อมูล

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // รับข้อมูลจากฟอร์ม
            $firstname = trim($_POST['firstname']);
            $surname = trim($_POST['surname']);
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);
            $email = trim($_POST['email']);

            // เข้ารหัสรหัสผ่านเพื่อความปลอดภัย
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // ตรวจสอบว่าชื่อผู้ใช้หรืออีเมลมีอยู่ในระบบหรือไม่
            $stmt = $conn->prepare("SELECT * FROM user WHERE username = ? OR email = ?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $checkResult = $stmt->get_result();

            if ($checkResult->num_rows > 0) {
                echo "<p class='error'>Username or Email already exists. Please use a different one.</p>";
            } else {
                // เพิ่มข้อมูลผู้ใช้ใหม่พร้อมค่า role เป็น 'reader'
                $stmt = $conn->prepare("INSERT INTO user (firstname, surname, username, password, email, role) VALUES (?, ?, ?, ?, ?, 'reader')");
                $stmt->bind_param("sssss", $firstname, $surname, $username, $hashed_password, $email);

                if ($stmt->execute()) {
                    echo "<p class='success'>Registration successful! You can now <a href='login.php'>login here</a>.</p>";
                } else {
                    echo "<p class='error'>Error: " . $stmt->error . "</p>";
                }
            }

            $stmt->close(); // ปิด statement
        }

        $conn->close(); // ปิดการเชื่อมต่อฐานข้อมูล
        ?>
    </section>
</body>
</html>
